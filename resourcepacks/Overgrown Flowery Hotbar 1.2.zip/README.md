# Overgrown Flowery Hotbar
This Resource pack is a standalone hotbar from my Overgrown Flowery GUI Pack. You can download the full pack here: https://modrinth.com/resourcepack/overgrown-flowery-gui
https://discord.gg/H9V6FuVGfT